//skinnyBot March 28th 2008

#include "Utilities.h"

char gBuffer[512];

// Credits: Dominik, Patrick
unsigned long dwStartAddress = 0x00801000, dwLen = 0x00B12000;

bool bDataCompare(const unsigned char* pData, const unsigned char* bMask, const char* szMask)
{
    for(;*szMask;++szMask,++pData,++bMask)
        if(*szMask=='x' && *pData!=*bMask )
            return false;
    return (*szMask) == 0;
}

unsigned long dwFindPattern( unsigned char *bMask,char * szMask)
{
	unsigned long dw_Address = dwStartAddress;
	unsigned long dw_Len = dwLen;

    for(unsigned long i=0; i < dw_Len; i++)
		if( bDataCompare( (unsigned char*)( dw_Address+i ),bMask,szMask) )
            return (unsigned long)(dw_Address+i);
    return 0;
}

void *DetourFunc(BYTE *src, const BYTE *dst, const int len)
{
	BYTE *jmp = (BYTE*)malloc(len+5);
	DWORD dwBack;

	VirtualProtect(src, len, PAGE_READWRITE, &dwBack);

	memcpy(jmp, src, len);	
	jmp += len;
	
	jmp[0] = 0xE9;
	*(DWORD*)(jmp+1) = (DWORD)(src+len - jmp) - 5;

	src[0] = 0xE9;
	*(DWORD*)(src+1) = (DWORD)(dst - src) - 5;

	for( int i=5; i < len; i++ )
		src[i] = 0x90;

	VirtualProtect(src, len, dwBack, &dwBack);

	return (jmp-len);
}

void RetourFunc(BYTE *src, BYTE *restore, const int len)
{
	DWORD dwBack;
		
	VirtualProtect(src, len, PAGE_READWRITE, &dwBack);
	memcpy(src, restore, len);

	restore[0] = 0xE9;
	*(DWORD*)(restore+1) = (DWORD)(src - restore) - 5;

	VirtualProtect(src, len, dwBack, &dwBack);
}

void MsgBox(char *Text, ...)
{
	va_list List;
	char Temp[256];

	va_start(List, Text);
		vsprintf(Temp, Text, List);
	va_end(List);

	MessageBox(GetDesktopWindow(), Temp, "Information", MB_OK | MB_APPLMODAL);
}

void MsgBoxError(char *Text, ...)
{
	va_list List;
	char Temp[256], Temp1[256];

	va_start(List, Text);
		vsprintf(Temp, Text, List);
	va_end(List);

	sprintf(Temp1, "Error: %s", Temp);

	MessageBox(GetDesktopWindow(), Temp1, "Application Error", MB_OK | MB_ICONSTOP | MB_APPLMODAL);
}

int WindowsErrorMsg()
{
    FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), 0, (LPTSTR)gBuffer,512, NULL);
	MessageBox(NULL, gBuffer, PROGRAM_NAME, MB_OK | MB_ICONINFORMATION);
  
	return false;
}