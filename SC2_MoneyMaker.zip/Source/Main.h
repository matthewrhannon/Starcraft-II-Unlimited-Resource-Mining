//skinnyM March 10 10
#pragma once

#define WIN32_LEAN_AND_MEAN

#define _CRT_SECURE_NO_DEPRECATE //Annoying

#pragma warning(disable:4996) //Depreciation annoyance
#pragma warning(disable:4254) //Merging attributes
#pragma warning(disable:4312) //DWORD to DWORD * of greater size

#define MessageBox  MessageBoxA

#include <windows.h>
#include <stdio.h>
#include <stdlib.h> //itoa etc

#include "Utilities.h"
#include "Logging.h"

#define inline __forceinline

#define PROGRAM_NAME "SC2MoneyMaker"
#define PROGRAM_VERSION "0.1 Alpha"

#define uint unsigned int
#define uchar unsigned char

extern char gBuffer[512];

#define SafeDelete(Object) {if(Object) delete Object; Object = 0}

#define QuickMsg(Text) MessageBox(NULL, Text, "Quick Message", MB_OK)

DWORD WINAPI InitalizeThread(LPVOID Parameter);




