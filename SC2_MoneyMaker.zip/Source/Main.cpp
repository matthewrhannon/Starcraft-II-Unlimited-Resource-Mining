//skinnyM March 10 10
#include "Main.h"

HANDLE hLoadThread = NULL;
#define MONEY_VALUE 100000

DWORD WINAPI InitalizeThread(LPVOID Parameter)
{
		Sleep(50);
		CLog::Get()->WriteEx("Entering Inital Thread");
	
		//Lets do something at this point...

		CLog::Get()->WriteEx("Finding function...\n");

	
		unsigned char *HexPattern = (BYTE *)"\x66\xa1\x00\x00\x00\x00\x66\x3d\xff\xff\x74\x00\x0f\xb7\xc8\xb8\x00\x00\x00\x00\xf7\xe1\xc1\xea\x02\x8b\xc2\x6b\xc0\x0d\x2b\xc8\x69\xc9\x00\x00\x00\x00\x03\x0c\x95\x00\x00\x00\x00\x85\xc9\x74\x00\x56\x0f\xb7\x41\x04\x66\x3d\xff\xff\x74\x00\x0f\xb7\xf0\xb8\x00\x00\x00\x00\xf7\xe6\xc1\xea\x02\x8b\xc2\x6b\xc0\x0d\x2b\xf0\x69\xf6\x00\x00\x00\x00\x03\x34\x95\x00\x00\x00\x00\xeb\x00";
		unsigned char *HexMask = (BYTE *)"xx????xxxxx?xxxx????xxxxxxxxxxxxxx????xxx????xxx?xxxxxxxxxx?xxxx????xxxxxxxxxxxxxx????xxx????x?";

		DWORD *pdwResourcesData = (DWORD *)(dwFindPattern((BYTE*)HexPattern, (char *)HexMask)+0x02); //Find the function!

		//Check return
		if(!pdwResourcesData)
		{
			MessageBeep(MB_ICONERROR); //Beep to let know unable to find function
			CLog::Get()->WriteEx("Unable to find address for resources");
		}
		else
		{
			MessageBeep(MB_OK); //Got it!

			CLog::Get()->WriteEx("Function Found: Address: 0x%0.8X -- Data: 0x%0.8X", pdwResourcesData, *pdwResourcesData);
		}

		//Increment to correct value
		DWORD *pdwResources = (DWORD *)*pdwResourcesData;

		//Wait and make sure the data is ready to edit
		while(*(pdwResources+0x02) != 1)
		{
			CLog::Get()->WriteEx("Valid: %u", *(pdwResources+0x02));
			Sleep(200);
		}

		pdwResources += 0x17;
		CLog::Get()->WriteEx("Data structure is valid! Money: Address: %u with Data: %u", pdwResources, *pdwResources);

		//Lets edit some stuff!
		CLog::Get()->WriteEx("About to start editing mineral and gas data");

		//The data we are looking for is 0x58 bytes apart (0x58/4 = 16)
		bool InvalidData = false;

		while(!InvalidData)
		{
			if(pdwResources)
			{
				if((*pdwResources == 1500) || (*pdwResources == 2500) || (pdwResources[1] == 1500) || (pdwResources[1] == 2500) || (pdwResources[1] == MONEY_VALUE)) //For inital minerals and gas values
				{
					*pdwResources = MONEY_VALUE;
					pdwResources[1] = MONEY_VALUE;

					pdwResources += 0x16; //Lets go to next money stack
				}
				else
					InvalidData = true;
			}
		}

		CLog::Get()->WriteEx("Checking if data was written...");

		pdwResources = (DWORD *)*pdwResourcesData;
		pdwResources += 0x17;
		if(*pdwResources == MONEY_VALUE)
			CLog::Get()->WriteEx("Money was successfully edited, atleast for one stack!");
		else
			CLog::Get()->WriteEx("Some error occured with validating that the money was indeed edited correctly");

		//Wait a moment...
		Sleep(100);
	

	//if(!(GetAsyncKeyState(VK_END) & 1))

	return 1;
}

bool __stdcall DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved)
{
	if(dwReason == DLL_PROCESS_ATTACH)
	{
		DisableThreadLibraryCalls(hInstance);
		CLog::Get()->Load(); //Initalize log
			
		//Make into a thread!
		hLoadThread = CreateThread(NULL, 0, InitalizeThread, NULL, NULL, NULL);
		if(!hLoadThread)
		{
			MsgBoxError("Error creating inital thread");
			return false;
		}
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		CloseHandle(hLoadThread);

		CLog::Get()->Write("Unloading");
		CLog::Get()->UnLoad();
	}
	
	return true;
}

