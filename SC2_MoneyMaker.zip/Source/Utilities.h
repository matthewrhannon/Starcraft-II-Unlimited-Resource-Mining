#pragma once

#include "Main.h"

// Credits: Dominik, Patrick
extern unsigned long dwStartAddress, dwLen;

bool bDataCompare( const unsigned char* pData, const unsigned char* bMask, const char* szMask );
unsigned long dwFindPattern( unsigned char *bMask,char * szMask);

void *DetourFunc(BYTE *src, const BYTE *dst, const int len);
void RetourFunc(BYTE *src, BYTE *restore, const int len);

void MsgBox(char *Text, ...);
void MsgBoxError(char *Text, ...);
int WindowsErrorMsg();
