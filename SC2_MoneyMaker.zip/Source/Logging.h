
//********************************************//
//				Log System
//********************************************//

#pragma once 

#include "Main.h"

class CLog
{
	public:
		static CLog *Get()
		{
			if(!Instance)
				Instance = new CLog;
			return Instance;
		}

		CLog();
		~CLog();

		void Load();
		void UnLoad();
		
		void Write(char *Text);
		void WriteEx(char *Text, ...);
		void WriteError(char *Text1, ...);
		void LineDown();

	private:
		static CLog *Instance;
		FILE *LogFile;

		char TempString1[64];
		char LogPath[32];
};
